﻿namespace KnapsakProblem_BranchBound
{
    public partial class KnapsakProblem_BranchBound
    {
        struct Item
        {
            public int weight;  // peso dell'oggetto
            public int value;   // valore dell'oggetto
        }

        // Variabili globali
        static List<Item> items = new List<Item>();  // la lista degli items
        static HashSet<int> best_knapsak = new HashSet<int>();  // Items nella soluzione migliore (inizialmente è uni zaino vuoto)
        static int best_total_value = 0;  // Valore degli items nella soluzione migliore (inizialmente è 0)



        static bool ReadFromFile(string file_name, List<Item> items, out int knapsak_capacity)
        {
            items.Clear();
            knapsak_capacity = 0;

            using (StreamReader sr = new StreamReader(file_name))
            {
                // il primo valore è la capacità dello zaino
                {
                    if (sr.EndOfStream)
                        return false;

                    if (!int.TryParse(sr.ReadLine(), out knapsak_capacity))
                        return false;
                }

                // ogni riga successiva contine peso e valore di un oggetto
                while (!sr.EndOfStream)
                {
                    string[] parts = sr.ReadLine().Split(',', StringSplitOptions.TrimEntries);

                    if (parts.Length < 2)  // ignora le righe con meno di due valori
                        continue;

                    Item item;
                    if (!int.TryParse(parts[0], out item.weight))
                        continue;
                    if (!int.TryParse(parts[1], out item.value))
                        continue;

                    items.Add(item);
                }

                sr.Close();
            }

            return true;
        }

        static double RunWithWatch(Action action)
        {
            var watch = new System.Diagnostics.Stopwatch();  // crea un oggetto in grado di misurare lo scorrere del tempo
            watch.Restart();  // fa partire il timer che misura lo scorrere del tempo

            action();  // esegue l'azione sottoposta a misurazione

            watch.Stop();  // arresta il timer, fissando il valore corrente
            return (double)watch.ElapsedMilliseconds / 1000.0;  // converte il valore in secondi
        }

        static void PrintKnapsack(List<Item> items, HashSet<int> knapsak)
        {
            Console.Write($"items = ");
            foreach (int item in knapsak)
            {
                Console.Write($"({items[item].weight}, {items[item].value}) ");
            }
            Console.WriteLine();
        }

        static List<Item> BuildVirtualItems(List<Item> items)
        {
            List<Item> virtual_items = new List<Item>();
            for (int item = 0; item<items.Count; item++)
            {
                Item virtual_item;
                virtual_item.weight = int.MaxValue;
                virtual_item.value = int.MinValue;
                for (int _item = item + 1; _item<items.Count; _item++)
                {
                    if (virtual_item.weight > items[_item].weight) { virtual_item.weight = items[_item].weight; }
                    if (virtual_item.value<items[_item].value) { virtual_item.value = items[_item].value; }
                }
                virtual_items.Add(virtual_item);
            }

            return virtual_items;
        }


        static void Resolve(int item, HashSet<int> knapsak, int remaing_weight, int total_value)
        {
            // Passo base
            if (item == items.Count)  // siamo all'ultimo livello dell'albero
            {
                // Valuta quanto è buona la soluzione trovata
                if (best_total_value < total_value)
                {
                    best_total_value = total_value;
                    best_knapsak = new HashSet<int>(knapsak);  // fa una copia della variabile knapsak
                }

                return;
            }

            // Calcola il "bound"

            // Applica l'eventuale cut
//            if (total_value + (double)remaing_weight / (double)virtual_items[item].weight * virtual_items[item].value < best_total_value)
//                return;

            // Passo ricorsivo : abbiamo due strade (1) prendere l'oggetto oppure (2) non prenderlo

            // Caso (1) : prendere l'oggetto
            if (items[item].weight <= remaing_weight)
            {
                knapsak.Add(item);
                Resolve(item + 1, knapsak, remaing_weight - items[item].weight, total_value + items[item].value);
                knapsak.Remove(item);  // ripristino la situazione
            }

            // Caso (2) : NON prendere l'oggetto
            Resolve(item + 1, knapsak, remaing_weight, total_value);
        }

        static void Main(string[] args)
        {
            string file_name = @"..\..\..\..\knapsak_10.txt";

            int knapsak_capacity;
            if (!ReadFromFile(file_name, items, out knapsak_capacity))
            {
                Console.WriteLine($"Errore leggendo i dati da '{file_name}'");
                return;
            }

            HashSet<int> knapsak = new HashSet<int>();  // inizialmente lo zaino è vuoto
            double elapsed = RunWithWatch(() => {
                Resolve(0, knapsak, knapsak_capacity, 0);
            });

            Console.WriteLine($"Elapsed = elapsed sec");
            Console.WriteLine($"best_total_value = {best_total_value}");
            PrintKnapsack(items, best_knapsak);
        }
    }
}
