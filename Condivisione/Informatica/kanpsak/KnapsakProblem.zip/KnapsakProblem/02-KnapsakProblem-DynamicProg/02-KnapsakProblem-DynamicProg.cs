﻿using System.Collections.Generic;

namespace KnapsakProblem_DynamicProg
{
    public partial class Program
    {
        struct Item
        {
            public int weight;  // peso dell'oggetto
            public int value;   // valore dell'oggetto
        }

        // Variabili globali
        static List<Item> items = new List<Item>();  // la lista degli items


        static bool ReadFromFile(string file_name, List<Item> items, out int knapsak_capacity)
        {
            items.Clear();
            knapsak_capacity = 0;

            using (StreamReader sr = new StreamReader(file_name))
            {
                // il primo valore è la capacità dello zaino
                {
                    if (sr.EndOfStream)
                        return false;

                    if (!int.TryParse(sr.ReadLine(), out knapsak_capacity))
                        return false;
                }

                // ogni riga successiva contine peso e valore di un oggetto
                while (!sr.EndOfStream)
                {
                    string[] parts = sr.ReadLine().Split(',', StringSplitOptions.TrimEntries);

                    if (parts.Length < 2)  // ignora le righe con meno di due valori
                        continue;

                    Item item;
                    if (!int.TryParse(parts[0], out item.weight))
                        continue;
                    if (!int.TryParse(parts[1], out item.value))
                        continue;

                    items.Add(item);
                }

                sr.Close();
            }

            return true;
        }

        static double RunWithWatch(Action action)
        {
            var watch = new System.Diagnostics.Stopwatch();  // crea un oggetto in grado di misurare lo scorrere del tempo
            watch.Restart();  // fa partire il timer che misura lo scorrere del tempo

            action();  // esegue l'azione sottoposta a misurazione

            watch.Stop();  // arresta il timer, fissando il valore corrente
            return (double)watch.ElapsedMilliseconds / 1000.0;  // converte il valore in secondi
        }

        static void PrintKnapsack(List<Item> items, HashSet<int> knapsak)
        {
            Console.Write($"items = ");
            foreach (int item in knapsak)
            {
                Console.Write($"({items[item].weight}, {items[item].value}) ");
            }
            Console.WriteLine();
        }



        static (int total_value, HashSet<int> knapsak) Resolve(int item, int remaing_weight)
        {
            // Passo base
            if (item == items.Count)  // siamo all'ultimo livello dell'albero (quello in cui non ci sono items da collocare!)
            {
                return (0, new HashSet<int>());
            }

            // Passo ricorsivo : abbiamo due strade (1) prendere l'oggetto oppure (2) non prenderlo

            // Caso (2) : NON prendere l'oggetto
            var res_2 = Resolve(item + 1, remaing_weight);

            // Caso (1) : prendere l'oggetto
            if (items[item].weight > remaing_weight)
            {
                return res_2;
            }

            var res_1 = Resolve(item + 1, remaing_weight - items[item].weight);

            if (res_2.total_value >= res_1.total_value + items[item].value)
            {
                return res_2;
            }

            HashSet<int> knapsak = new HashSet<int>(res_1.knapsak);
            knapsak.Add(item);
            return (res_1.total_value + items[item].value, knapsak);
        }

        static void Main(string[] args)
        {
            string file_name = @"..\..\..\..\knapsak_10.txt";

            int knapsak_capacity;
            if (!ReadFromFile(file_name, items, out knapsak_capacity))
            {
                Console.WriteLine($"Errore leggendo i dati da '{file_name}'");
                return;
            }

            (int total_value, HashSet<int> knapsak) sol = (0, new HashSet<int>());
            double elapsed = RunWithWatch(() => {
                sol = Resolve(0, knapsak_capacity);
            });

            Console.WriteLine($"Elapsed = elapsed sec");
            Console.WriteLine($"best_total_value = {sol.total_value}");
            PrintKnapsack(items, sol.knapsak);
        }
    }
}
