#!/bin/bash

#Pietro_Malzone_04/12/2023

echo "Premere 1 per effettuare il lancio della moneta"
echo "Premere 2 per effettuare il lancio dei dadi"

read n

if ((n == 1))
then 
    NUM_MAX=2

    echo "Quanti lanci della moneta vuole effetuare"
    read  n_lanci


    for ((i = 1; i <= n_lanci; i++))
    do
        numero=$RANDOM
        numero=$(($numero%$NUM_MAX))

        if ((numero == 0))
            then
                echo "Tiro n: $i"
                echo "numero = $numero"
                echo "è uscita testa"
        else
                echo "Tiro n: $i"
                echo "numero = $numero"
                echo "è uscita croce"
        fi                
    done
else
    echo "Quante facce ha il primo dado? -->"
    read a
    echo "Quante facce ha il primo dado? -->"
    read b


    numeroA=$RANDOM
    numeroA=$((numeroA%a))

    numeroB=$RANDOM
    numeroB=$((numeroB%b))

    let "numeroA+=1"
    let "numeroB+=1"
    somma=0
    let "somma=numeroA+numeroB"

    echo "Dado 1 = $numeroA , Dado 2 = $numeroB , Somma = $somma"
fi