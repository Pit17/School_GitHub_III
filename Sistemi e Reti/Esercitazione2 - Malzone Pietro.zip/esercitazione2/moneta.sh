#!/bin/bash

#Pietro_Malzone_27/11/2023

NUM_MAX=2

echo "Quanti lanci della moneta vuole effetuare"
read  n_lanci


for ((i = 1; i <= n_lanci; i++))
    do
        numero=$RANDOM
        numero=$(($numero%$NUM_MAX))

        if ((numero == 0))
            then
                echo "Tiro n: $i"
                echo "numero = $numero"
                echo "è uscita testa"
        else
                echo "Tiro n: $i"
                echo "numero = $numero"
                echo "è uscita croce"
        fi                
    done
