#!/bin/bash

#Pietro_Malzone_27/11/2023

echo "Fino a quale numero vuole stampare numeri dispari?"
read  n_max
j=1
# for ((i=1; i<=_max; i+=2))
#     do
#         echo "$i;"
#     done

while [ "$j" -le $n_max ]
do
    echo "$j;"
    let "j+=2"
done