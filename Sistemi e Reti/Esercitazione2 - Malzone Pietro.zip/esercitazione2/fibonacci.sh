#!/bin/bash

#Pietro_Malzone_27/11/2023
echo "Inserire numero massimo"
read n

for (( i = 1 , j = 1 ; i<= n ; i += j, j += i ))
     do
        echo -n "$i" "$j "
      done 
      echo