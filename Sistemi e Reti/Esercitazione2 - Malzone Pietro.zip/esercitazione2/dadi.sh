#!/bin/bash

#Pietro_Malzone_04/12/2023

echo "Quante facce ha il primo dado? -->"
read a
echo "Quante facce ha il primo dado? -->"
read b


numeroA=$RANDOM
numeroA=$((numeroA%a))

numeroB=$RANDOM
numeroB=$((numeroB%b))

let "numeroA+=1"
let "numeroB+=1"
somma=0
let "somma=numeroA+numeroB"

echo "Dado 1 = $numeroA , Dado 2 = $numeroB , Somma = $somma"