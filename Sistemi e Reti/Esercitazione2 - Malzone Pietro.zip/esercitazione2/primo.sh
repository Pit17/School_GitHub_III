#!/bin/bash

#Pietro_Malzone_04/12/2023

echo "Inserire un numero per verificare se primo"
read num

flag=0

for (( i = 2; i<num; i++ ))
do
    if (($num%$i==0))
    then
        let "flag = 1"
    fi

done

if (($flag == 1))
then    
    echo "il numero non è primo"
else 
    echo "il numero è primo"
fi