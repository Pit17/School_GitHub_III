#!/bin/bash

#Pietro_Malzone_04/12/2023


ciclo=1

while (($ciclo == 1))
do
    
    echo "Premere 1 per effettuare il lancio della moneta"
    echo "Premere 2 per effettuare il lancio dei dadi"  
    echo "Premere 3 per uscire dal programma"
    read n
    if ((n == 1))
    then
        ./moneta.sh
    elif ((n == 2))
    then
        ./dadi.sh
    else
        let "ciclo+=1"
    fi
done
